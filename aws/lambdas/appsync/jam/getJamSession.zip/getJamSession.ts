import { AppSyncResolverEvent } from 'aws-lambda'
import { DynamoDBClient, GetItemCommand, BatchGetItemCommand, QueryCommand } from '@aws-sdk/client-dynamodb'
import { unmarshall } from '@aws-sdk/util-dynamodb'

import { hasSubstring, merge } from '../../util/dynamo'

import { Participant, User } from '../../API'
import { _JamSession, _JamSong, _SetList } from '../../type'

const USER_TABLE_NAME = process.env.USER_TABLE_NAME || ''
const SETLIST_TABLE_NAME = process.env.SETLIST_TABLE_NAME || ''
const SONG_TABLE_NAME = process.env.SONG_TABLE_NAME || ''
const JAM_TABLE_NAME = process.env.JAM_TABLE_NAME || ''
const USER_BAND_MEMBERSHIP_TABLE_NAME = process.env.USER_BAND_MEMBERSHIP_TABLE_NAME || ''

export const handler = async (event: AppSyncResolverEvent<{
  jamSessionId: string, userId?: string
}, null>) => {
  console.log(event)
  const b = event.arguments
  if (!b) { console.error(`event.arguments is empty`); return }
  if (!b.jamSessionId) { console.error(`b.setListId is empty`); return }
  
  const dynamo = new DynamoDBClient({})
  const res1 = await dynamo.send(
    new GetItemCommand({
      TableName: JAM_TABLE_NAME,
      Key: { jamSessionId: { S: b.jamSessionId } }
    })
  )
  if (!res1.Item) { console.error(`ERROR: jamSessionId not found: ${b.jamSessionId}`); return }
  let jamSession = unmarshall(res1.Item) as _JamSession
  
  // Ensure required fields are initialized
  if (!jamSession.admins) jamSession.admins = []
  if (!jamSession.members) jamSession.members = []
  if (!jamSession.guests) jamSession.guests = []
  if (!jamSession.active) jamSession.active = []
  if (!jamSession.queue) jamSession.queue = []
  if (jamSession.revision === undefined || jamSession.revision === null) jamSession.revision = 0

  // check authorization
  if (jamSession.policy === "PRIVATE") {
    if (!b.userId) { 
      console.error(`This is a private jam session and no userId provided.`)
      throw new Error('Access denied: Private jam session requires authentication')
    }
    
    // Check if user is a member of the band that owns this jam session
    if (jamSession.bandId) {
      console.log(`Checking band membership for user ${b.userId} in band ${jamSession.bandId}`)
      const membershipRes = await dynamo.send(new QueryCommand({
        TableName: USER_BAND_MEMBERSHIP_TABLE_NAME,
        KeyConditionExpression: 'userId = :userId AND bandId = :bandId',
        ExpressionAttributeValues: {
          ':userId': { S: b.userId },
          ':bandId': { S: jamSession.bandId }
        }
      }))
      
      if (!membershipRes.Items || membershipRes.Items.length === 0) {
        console.error(`User ${b.userId} is not a member of band ${jamSession.bandId}`)
        throw new Error('Access denied: User is not a member of the band')
      }
      
      console.log(`User ${b.userId} is authorized to access jam session ${b.jamSessionId}`)
    } else {
      console.error(`Jam session ${b.jamSessionId} is private but has no bandId`)
      throw new Error('Access denied: Private jam session has no associated band')
    }
  }

  if (hasSubstring(event.info.selectionSetList, "setList")) {
    console.log("getting setList ...")
    const res2 = await dynamo.send(
      new GetItemCommand({
        TableName: SETLIST_TABLE_NAME,
        Key: { setListId: { S: jamSession.setListId } }
      })
    )
    if (!res2.Item) { console.error(`ERROR: setListId not found: ${jamSession.setListId}`); return }

    let setList = unmarshall(res2.Item) as _SetList
    console.log(setList)

    if (hasSubstring(event.info.selectionSetList, "setList/songCache")) {
      console.log("getting setList/songCache ..")
      
      // Check if setList has songs in the old format (JamSong array)
      if (setList.songs && Array.isArray(setList.songs)) {
        console.log("Found songs in old format, converting to songCache")
        const songIds = (setList.songs as _JamSong[]).map((s) => { return s!.songId as string })
        const uniq = Array.from(new Set(songIds))
    
        const keys = uniq.map((s) => { return { songId: { S: s } } as { [songId: string]: any } })
        console.log(keys)
    
        const res1 = await dynamo.send(new BatchGetItemCommand({
          RequestItems: {[SONG_TABLE_NAME]: { Keys: keys }}
        }))
        console.log(res1)
        if (!res1.Responses) { console.error(`ERROR: unable to BatchGet songId. ${res1.$metadata}`); return  } 
    
        const songs = res1.Responses![SONG_TABLE_NAME].map((u) => unmarshall(u))
        console.log(songs)

        // Convert to songCache format
        setList.songCache = songs
      } else if (setList.songCache && Array.isArray(setList.songCache)) {
        console.log("Found songCache in new format, using as-is")
        // songCache is already in the correct format
      } else {
        console.log("No songs found in setList, songCache will be null")
        setList.songCache = null
      }
    }

    if (hasSubstring(event.info.selectionSetList, "setList/creator")) {
      console.log("getting setList/creator ..")
      const res2 = await dynamo.send(new GetItemCommand({
        TableName: USER_TABLE_NAME, Key: { userId: { S: setList.userId } }
      }))
      console.log(res2)
      if (!res2.Item) { console.error(`ERROR: unable to get setList.userId. ${res1.$metadata}`); return  }
      let creator = unmarshall(res2.Item) as User

      if (!creator.labelledRecording) creator.labelledRecording = []
      if (!creator.songsCreated) creator.songsCreated = []
      if (!creator.likedSongs) creator.likedSongs = []
      if (!creator.friends) creator.friends = []
      
      setList.creator = creator
    }

    // TODO: editors
    if (hasSubstring(event.info.selectionSetList, "setList/editors")) {
      setList.editors = []
    }
    
    jamSession.setList = setList
  }

  if (hasSubstring(event.info.selectionSetList, "admins")) {
    // Get admins from the jam session creator and band admins
    const adminIds = [jamSession.userId] // Creator is always an admin
    if (jamSession.bandId) {
      // Add band admins
      const bandAdminsRes = await dynamo.send(new QueryCommand({
        TableName: USER_BAND_MEMBERSHIP_TABLE_NAME,
        IndexName: 'bandId-index',
        KeyConditionExpression: 'bandId = :bandId',
        FilterExpression: '#role = :adminRole',
        ExpressionAttributeNames: {
          '#role': 'role'
        },
        ExpressionAttributeValues: {
          ':bandId': { S: jamSession.bandId },
          ':adminRole': { S: 'ADMIN' }
        }
      }))
      
      if (bandAdminsRes.Items) {
        const bandAdminIds = bandAdminsRes.Items.map(item => unmarshall(item).userId)
        adminIds.push(...bandAdminIds)
      }
    }
    
    // Get admin user details (deduplicate first)
    const uniqueAdminIds = Array.from(new Set(adminIds))
    const adminKeys = uniqueAdminIds.map(id => ({ userId: { S: id } }))
    if (adminKeys.length > 0) {
      const adminRes = await dynamo.send(new BatchGetItemCommand({
        RequestItems: {[USER_TABLE_NAME]: { Keys: adminKeys as any }}
      }))
      
      if (adminRes.Responses) {
        jamSession.admins = adminRes.Responses[USER_TABLE_NAME].map(u => {
          let user = unmarshall(u) as User
          if (!user.labelledRecording) user.labelledRecording = []
          if (!user.songsCreated) user.songsCreated = []
          if (!user.likedSongs) user.likedSongs = []
          if (!user.friends) user.friends = []
          return user
        })
      }
    }
  }

  if (hasSubstring(event.info.selectionSetList, "members")) {
    // Get band members
    if (jamSession.bandId) {
      const membersRes = await dynamo.send(new QueryCommand({
        TableName: USER_BAND_MEMBERSHIP_TABLE_NAME,
        IndexName: 'bandId-index',
        KeyConditionExpression: 'bandId = :bandId',
        ExpressionAttributeValues: {
          ':bandId': { S: jamSession.bandId }
        }
      }))
      
      if (membersRes.Items) {
        const memberIds = membersRes.Items.map(item => unmarshall(item).userId)
        const uniqueMemberIds = Array.from(new Set(memberIds))
        const memberKeys = uniqueMemberIds.map(id => ({ userId: { S: id } }))
        
        if (memberKeys.length > 0) {
          const memberRes = await dynamo.send(new BatchGetItemCommand({
            RequestItems: {[USER_TABLE_NAME]: { Keys: memberKeys as any }}
          }))
          
          if (memberRes.Responses) {
            jamSession.members = memberRes.Responses[USER_TABLE_NAME].map(u => {
              let user = unmarshall(u) as User
              if (!user.labelledRecording) user.labelledRecording = []
              if (!user.songsCreated) user.songsCreated = []
              if (!user.likedSongs) user.likedSongs = []
              if (!user.friends) user.friends = []
              return user
            })
          }
        }
      }
    }
  }

  if (hasSubstring(event.info.selectionSetList, "guests")) {
    jamSession.guests = [] // Guests are handled separately in active participants
  }

  if (hasSubstring(event.info.selectionSetList, "active")) {
    console.log("getting active ..")
    const tmp = (jamSession.active || []).map((s) => { 
      if (s?.participantType === "USER") return  s?.userId || ""
      return ""
    }).filter((i) => { return i != "" }) as string[]
    const uniq = Array.from(new Set(tmp))

    const keys = uniq.map((s) => { return { userId: { S: s } }})
    
    if (keys.length > 0) {
      const res1 = await dynamo.send(new BatchGetItemCommand({
        RequestItems: {[USER_TABLE_NAME]: { Keys: keys }}
      }))
      console.log(res1)
      if (!res1.Responses) { console.error(`ERROR: unable to BatchGet userId. ${res1.$metadata}`); return  } 
  
      const active = res1.Responses![USER_TABLE_NAME].map((u) => {
        let user = unmarshall(u) as User
  
        if (!user.labelledRecording) user.labelledRecording = []
        if (!user.songsCreated) user.songsCreated = []
        if (!user.likedSongs) user.likedSongs = []
        if (!user.friends) user.friends = []
  
        return user
      })

      console.log(JSON.stringify(jamSession.active))
      jamSession.active = merge(jamSession.active, active, "userId", "user") as Participant[]
      console.log(JSON.stringify(jamSession.active))
    } else {
      // Ensure active is always an array, even if empty
      jamSession.active = jamSession.active || []
    }
  }
  
  console.log(JSON.stringify(jamSession))
  return jamSession
}