"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const dynamo_1 = require("../../util/dynamo");
const JAM_TABLE_NAME = process.env.JAM_TABLE_NAME || '';
// type _JamSession = JamSession & {
//   setListId: string
// }
// type _SetList = SetList & {
//   userId: string
//   songs: _JamSong[]
// }
// type _JamSong = JamSong & {
//   songId: string
// }
const handler = async (event) => {
    console.log(event);
    const b = event.arguments;
    if (!b) {
        console.error(`event.arguments is empty`);
        return;
    }
    if (!b.jamSessionId) {
        console.error(`b.creatorId is empty`);
        return;
    }
    const dynamo = new client_dynamodb_1.DynamoDBClient({});
    // let page = {
    //   jamSessionId: b.jamSessionId,
    //   songId: "",
    //   page: 0
    // }
    // const res0 = await dynamo.send(
    //   new GetItemCommand({
    //     TableName: JAM_TABLE_NAME, Key: { jamSessionId: { S: b.jamSessionId } }
    //   })
    // )
    // if (!res0.Item) { console.error(`ERROR: jamSessionId not found: ${b.jamSessionId}`); return }
    // const jamSession = unmarshall(res0.Item) as _JamSession
    // if (jamSession.currentPage && jamSession.currentSong) {
    //   page.page = jamSession.currentPage
    // }
    console.log(`page: ${b.page}`);
    const params = (0, dynamo_1.updateDynamoUtil)({
        table: JAM_TABLE_NAME,
        key: { jamSessionId: b.jamSessionId },
        item: { currentPage: b.page }
    });
    console.log(params);
    console.log("params calculated");
    const res1 = await dynamo.send(new client_dynamodb_1.UpdateItemCommand(params));
    console.log("res1 result");
    console.log(res1);
    return { jamSessionId: b.jamSessionId, page: b.page };
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmV4dFBhZ2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJuZXh0UGFnZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSw4REFBNEU7QUFDNUUsOENBQW9EO0FBRXBELE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxJQUFJLEVBQUUsQ0FBQTtBQUV2RCxvQ0FBb0M7QUFDcEMsc0JBQXNCO0FBQ3RCLElBQUk7QUFFSiw4QkFBOEI7QUFDOUIsbUJBQW1CO0FBQ25CLHNCQUFzQjtBQUN0QixJQUFJO0FBRUosOEJBQThCO0FBQzlCLG1CQUFtQjtBQUNuQixJQUFJO0FBRUcsTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFFLEtBRXRCLEVBQUUsRUFBRTtJQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDbEIsTUFBTSxDQUFDLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQTtJQUN6QixJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFBQyxPQUFPLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLENBQUM7UUFBQyxPQUFNO0lBQUMsQ0FBQztJQUM3RCxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQUMsT0FBTTtJQUFDLENBQUM7SUFFdEUsTUFBTSxNQUFNLEdBQUcsSUFBSSxnQ0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBRXJDLGVBQWU7SUFDZixrQ0FBa0M7SUFDbEMsZ0JBQWdCO0lBQ2hCLFlBQVk7SUFDWixJQUFJO0lBRUosa0NBQWtDO0lBQ2xDLHlCQUF5QjtJQUN6Qiw4RUFBOEU7SUFDOUUsT0FBTztJQUNQLElBQUk7SUFDSixnR0FBZ0c7SUFDaEcsMERBQTBEO0lBQzFELDBEQUEwRDtJQUMxRCx1Q0FBdUM7SUFDdkMsSUFBSTtJQUVKLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQTtJQUc5QixNQUFNLE1BQU0sR0FBRyxJQUFBLHlCQUFnQixFQUFDO1FBQzlCLEtBQUssRUFBRSxjQUFjO1FBQ3JCLEdBQUcsRUFBRSxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUMsWUFBWSxFQUFFO1FBQ3JDLElBQUksRUFBRSxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFO0tBQzlCLENBQUMsQ0FBQTtJQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDbkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO0lBQ2hDLE1BQU0sSUFBSSxHQUFHLE1BQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLG1DQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUE7SUFFN0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQTtJQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO0lBRWpCLE9BQU8sRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFDLFlBQVksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFBO0FBQ3ZELENBQUMsQ0FBQTtBQTVDWSxRQUFBLE9BQU8sV0E0Q25CIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBwU3luY1Jlc29sdmVyRXZlbnQgfSBmcm9tICdhd3MtbGFtYmRhJ1xuaW1wb3J0IHsgRHluYW1vREJDbGllbnQsIFVwZGF0ZUl0ZW1Db21tYW5kIH0gZnJvbSAnQGF3cy1zZGsvY2xpZW50LWR5bmFtb2RiJ1xuaW1wb3J0IHsgdXBkYXRlRHluYW1vVXRpbCB9IGZyb20gJy4uLy4uL3V0aWwvZHluYW1vJ1xuXG5jb25zdCBKQU1fVEFCTEVfTkFNRSA9IHByb2Nlc3MuZW52LkpBTV9UQUJMRV9OQU1FIHx8ICcnXG5cbi8vIHR5cGUgX0phbVNlc3Npb24gPSBKYW1TZXNzaW9uICYge1xuLy8gICBzZXRMaXN0SWQ6IHN0cmluZ1xuLy8gfVxuXG4vLyB0eXBlIF9TZXRMaXN0ID0gU2V0TGlzdCAmIHtcbi8vICAgdXNlcklkOiBzdHJpbmdcbi8vICAgc29uZ3M6IF9KYW1Tb25nW11cbi8vIH1cblxuLy8gdHlwZSBfSmFtU29uZyA9IEphbVNvbmcgJiB7XG4vLyAgIHNvbmdJZDogc3RyaW5nXG4vLyB9XG5cbmV4cG9ydCBjb25zdCBoYW5kbGVyID0gYXN5bmMgKGV2ZW50OiBBcHBTeW5jUmVzb2x2ZXJFdmVudDx7XG4gIGphbVNlc3Npb25JZDogc3RyaW5nLCBwYWdlOiBudW1iZXJcbn0sIG51bGw+KSA9PiB7XG4gIGNvbnNvbGUubG9nKGV2ZW50KVxuICBjb25zdCBiID0gZXZlbnQuYXJndW1lbnRzXG4gIGlmICghYikgeyBjb25zb2xlLmVycm9yKGBldmVudC5hcmd1bWVudHMgaXMgZW1wdHlgKTsgcmV0dXJuIH1cbiAgaWYgKCFiLmphbVNlc3Npb25JZCkgeyBjb25zb2xlLmVycm9yKGBiLmNyZWF0b3JJZCBpcyBlbXB0eWApOyByZXR1cm4gfVxuXG4gIGNvbnN0IGR5bmFtbyA9IG5ldyBEeW5hbW9EQkNsaWVudCh7fSlcblxuICAvLyBsZXQgcGFnZSA9IHtcbiAgLy8gICBqYW1TZXNzaW9uSWQ6IGIuamFtU2Vzc2lvbklkLFxuICAvLyAgIHNvbmdJZDogXCJcIixcbiAgLy8gICBwYWdlOiAwXG4gIC8vIH1cblxuICAvLyBjb25zdCByZXMwID0gYXdhaXQgZHluYW1vLnNlbmQoXG4gIC8vICAgbmV3IEdldEl0ZW1Db21tYW5kKHtcbiAgLy8gICAgIFRhYmxlTmFtZTogSkFNX1RBQkxFX05BTUUsIEtleTogeyBqYW1TZXNzaW9uSWQ6IHsgUzogYi5qYW1TZXNzaW9uSWQgfSB9XG4gIC8vICAgfSlcbiAgLy8gKVxuICAvLyBpZiAoIXJlczAuSXRlbSkgeyBjb25zb2xlLmVycm9yKGBFUlJPUjogamFtU2Vzc2lvbklkIG5vdCBmb3VuZDogJHtiLmphbVNlc3Npb25JZH1gKTsgcmV0dXJuIH1cbiAgLy8gY29uc3QgamFtU2Vzc2lvbiA9IHVubWFyc2hhbGwocmVzMC5JdGVtKSBhcyBfSmFtU2Vzc2lvblxuICAvLyBpZiAoamFtU2Vzc2lvbi5jdXJyZW50UGFnZSAmJiBqYW1TZXNzaW9uLmN1cnJlbnRTb25nKSB7XG4gIC8vICAgcGFnZS5wYWdlID0gamFtU2Vzc2lvbi5jdXJyZW50UGFnZVxuICAvLyB9XG5cbiAgY29uc29sZS5sb2coYHBhZ2U6ICR7Yi5wYWdlfWApXG5cblxuICBjb25zdCBwYXJhbXMgPSB1cGRhdGVEeW5hbW9VdGlsKHsgXG4gICAgdGFibGU6IEpBTV9UQUJMRV9OQU1FLCBcbiAgICBrZXk6IHsgamFtU2Vzc2lvbklkOiBiLmphbVNlc3Npb25JZCB9LFxuICAgIGl0ZW06IHsgY3VycmVudFBhZ2U6IGIucGFnZSB9IFxuICB9KVxuXG4gIGNvbnNvbGUubG9nKHBhcmFtcylcbiAgY29uc29sZS5sb2coXCJwYXJhbXMgY2FsY3VsYXRlZFwiKVxuICBjb25zdCByZXMxID0gYXdhaXQgZHluYW1vLnNlbmQobmV3IFVwZGF0ZUl0ZW1Db21tYW5kKHBhcmFtcykpXG4gIFxuICBjb25zb2xlLmxvZyhcInJlczEgcmVzdWx0XCIpXG4gIGNvbnNvbGUubG9nKHJlczEpXG5cbiAgcmV0dXJuIHsgamFtU2Vzc2lvbklkOiBiLmphbVNlc3Npb25JZCwgcGFnZTogYi5wYWdlIH1cbn0iXX0=