"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const util_dynamodb_1 = require("@aws-sdk/util-dynamodb");
// Utility functions (inline to avoid import issues)
function hasSubstring(strings, substring) {
    return strings.some((str) => str.includes(substring));
}
const merge = (a1, a2, matchKey, outputKey) => {
    return a1.map((o1) => {
        const matchingObj = a2.find((o2) => o2[matchKey] === o1[matchKey]);
        if (!outputKey)
            return matchingObj ? { ...o1, ...matchingObj } : o1;
        else
            return matchingObj ? { ...o1, [outputKey]: matchingObj } : o1;
    });
};
const dynamo = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const JAM_TABLE_NAME = process.env.JAM_TABLE_NAME || 'oslynstudio-JamSessionTable-1A2B3C4D5E6F';
const SETLIST_TABLE_NAME = process.env.SETLIST_TABLE_NAME || 'oslynstudio-SetListTable-1A2B3C4D5E6F';
const SONG_TABLE_NAME = process.env.SONG_TABLE_NAME || 'oslynstudio-SongTable-1A2B3C4D5E6F';
const handler = async (event) => {
    console.log('getJamSession event:', JSON.stringify(event, null, 2));
    const { jamSessionId, userId } = event.arguments;
    if (!jamSessionId) {
        console.error('ERROR: jamSessionId is required');
        return null;
    }
    console.log('Getting jam session:', jamSessionId);
    console.log('User ID:', userId);
    // Get jam session from DynamoDB
    const res = await dynamo.send(new client_dynamodb_1.GetItemCommand({
        TableName: JAM_TABLE_NAME,
        Key: { jamSessionId: { S: jamSessionId } }
    }));
    if (!res.Item) {
        console.error(`ERROR: jamSessionId not found: ${jamSessionId}`);
        return null;
    }
    const jamSession = (0, util_dynamodb_1.unmarshall)(res.Item);
    console.log('Jam session found:', jamSession);
    // Check if user has access to this jam session
    if (jamSession.policy === 'PRIVATE') {
        console.log('Checking private access for user:', userId);
        if (!userId) {
            console.error('ERROR: userId is required for private jam sessions');
            return null;
        }
        // Check if user is admin, member, or guest (with null checks)
        const isAdmin = jamSession.admins && Array.isArray(jamSession.admins) ?
            jamSession.admins.some(admin => admin && admin.userId === userId) : false;
        const isMember = jamSession.members && Array.isArray(jamSession.members) ?
            jamSession.members.some(member => member && member.userId === userId) : false;
        const isGuest = jamSession.guests && Array.isArray(jamSession.guests) ?
            jamSession.guests.some(guest => guest && guest.userId === userId) : false;
        // If no authorization arrays exist, check if user is the creator
        const isCreator = jamSession.userId === userId;
        if (!isAdmin && !isMember && !isGuest && !isCreator) {
            console.error(`ERROR: User ${userId} does not have access to private jam session ${jamSessionId}`);
            return null;
        }
        console.log('User has access to private jam session');
    }
    // Get setList if requested
    if (hasSubstring(event.info.selectionSetList, "setList")) {
        console.log("getting setList ...");
        console.log("jamSession.setListId:", jamSession.setListId);
        // Check if jamSession has setListId, if not, try to get it from the setList field
        let setListId = jamSession.setListId;
        if (!setListId && jamSession.setList && jamSession.setList.setListId) {
            setListId = jamSession.setList.setListId;
        }
        if (!setListId) {
            console.error(`ERROR: No setListId found for jam session ${jamSessionId}`);
            return null;
        }
        const res2 = await dynamo.send(new client_dynamodb_1.GetItemCommand({
            TableName: SETLIST_TABLE_NAME,
            Key: { setListId: { S: setListId } }
        }));
        if (!res2.Item) {
            console.error(`ERROR: setListId not found: ${setListId}`);
            return null;
        }
        let setList = (0, util_dynamodb_1.unmarshall)(res2.Item);
        console.log('SetList found:', setList);
        if (hasSubstring(event.info.selectionSetList, "setList/songCache")) {
            console.log("getting setList/songCache ..");
            // Check if setList has songs in the old format (JamSong array)
            if (setList.songs && Array.isArray(setList.songs)) {
                console.log("Found songs in old format, converting to songCache");
                const songIds = setList.songs.map((s) => { return s.songId; });
                const uniq = Array.from(new Set(songIds));
                const keys = uniq.map((s) => { return { songId: { S: s } }; });
                console.log(keys);
                const res1 = await dynamo.send(new client_dynamodb_1.BatchGetItemCommand({
                    RequestItems: { [SONG_TABLE_NAME]: { Keys: keys } }
                }));
                console.log(res1);
                if (!res1.Responses) {
                    console.error(`ERROR: unable to BatchGet songId. ${res1.$metadata}`);
                    return;
                }
                const songs = res1.Responses[SONG_TABLE_NAME].map((u) => (0, util_dynamodb_1.unmarshall)(u));
                console.log(songs);
                // Convert to songCache format
                setList.songCache = songs;
            }
            else if (setList.songCache && Array.isArray(setList.songCache)) {
                console.log("Found songCache in new format, using as is");
                // songCache already exists, use it
            }
            else {
                console.log("No songs found in setList, songCache will be null");
                setList.songCache = null;
            }
        }
        jamSession.setList = setList;
    }
    return jamSession;
};
exports.handler = handler;
